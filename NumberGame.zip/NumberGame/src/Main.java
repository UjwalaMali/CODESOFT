
public class Main {
	public static void main(String[] args) {
        NumberGuess g = new NumberGuess();

        g.playGame();
    }
}
